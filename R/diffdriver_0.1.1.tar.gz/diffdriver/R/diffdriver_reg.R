# TODO: mutation hotspot, quantitative phenotype
# Notes: syn data prepared from direct join of mutation list to annodata is different from used in driverMAPS BMR estimation: 1. 5% syn are ssp are included. 2. BMR estimation from old driverMAPS run has different annodata. 3. genes without expr/hic/rep were removed in BMR driverMAPS estimation.
#' @title Run diffDriver given input files
#' @description This is the function to run diffDriver. We first need to set up: run driverMAPS for groups with potential different BMR, assign BMR labels for each sample. then BMR for each sample will be scaled based on driverMAPS results.
#' @param genef file for name of genes to be included in the analysis
#' @param mutf mutation list file, use the driverMAPS mutation input format
#' @param phenof phenptype file, SampleID <tab> Phenotype <tab> Nsyn. nsyn is number of syn mutations in this sample.
#' @param j The index of phenotype
#' @import Matrix data.table
#' @export
diffdriver_reg <- function(genef, mutf, phenof,j,hotf, drivermapsdir, outputdir =".", outputname = "diffdriver_results"){
  # ------- read position level information (same as in drivermaps) ----------
  adirbase <-drivermapsdir
  afileinfo <- list(file = paste(adirbase, "nttypeXXX_annodata.txt", sep=""),
                    header = c("chrom","start","end","ref","alt","genename","functypecode","nttypecode","expr","repl","hic","mycons","sift","phylop100","MA","ssp","wggerp"),
                    coltype = c("character","numeric","numeric","character","character","character","character","factor","numeric","numeric","numeric","numeric","numeric","numeric","numeric","numeric","numeric"))
  totalnttype <- 9
  Totalnttype <- 9
 bmvars <- c("nttypecode", "expr", "repl", "hic")
  bmmuttype <- "functypecode == 6 & ssp == 0"
  funcvars <- c("functypecode", "mycons", "sift", "phylop100", "MA")
  functypecodelevel <- "7"
  funcvmuttype <- "functypecode == 7 | functypecode == 8"
  readinvars <- c("genename", "ssp",bmvars, funcvars) # This is optional, if not given, then will read all columns
  qnvars = c("expr","repl","hic") # all the rest will be normalized, except for nttypecode
  outputbase <- paste0(outputdir, "/", outputname)
  paramdir <- paste0(drivermapsdir, "/param/")
  fixmusdfile <-  paste0(paramdir, "colmu_sd_funct78.Rdata")

  allg <- read.table(genef, stringsAsFactors = F)[,1]
matrixlist <- readmodeldata(afileinfo, yfileinfo = NULL, c(bmvars,funcvars), funcvmuttype, readinvars , qnvars, functypecodelevel,qnvarimpute=c(0,0), cvarimpute = 0, genesubset=genef, fixmusd=fixmusdfile)
chrposmatrixlist <- ddmread(afileinfo, yfileinfo = NULL, c("chrom", "start","ref","alt"), funcvmuttype, c("genename", "chrom", "start", "ref", "alt", "functypecode", "ssp", "nttypecode"), genesubset=genef)

#save(matrixlist,file="matrixlist9.Rd")
#save(chrposmatrixlist,file="chrposmatrixlist9.Rd")
#load("matrixlist9.Rd")
#load("chrposmatrixlist9.Rd")
BMRlist=BMRlist$UCS

for (t in 1:length(matrixlist)){
    b1 <- which(sapply(matrixlist[[t]][[3]], grepl, pattern="[;,|]"))
    matrixlist[[t]][[3]][b1,] <- unlist(lapply(sapply(matrixlist[[t]][[3]][b1,], strsplit, split="[;,|]"), function(x) intersect(x,allg)[1]))
    b2 <- which(sapply(chrposmatrixlist[[t]][[3]], grepl, pattern="[;,|]"))
    chrposmatrixlist[[t]][[3]][b2,] <- unlist(lapply(sapply(matrixlist[[t]][[3]][b2,], strsplit, split="[;,|]"), function(x) intersect(x,allg)[1]))

    }
  #------------------------------------------------------------------------------

  # background mutation rate (bmrdt): data.table, each column correponds to one BMR label
  bmrdt <- data.table()


    matrixlisttemp <- copy(matrixlist)
    chrposmatrixlisttemp <- copy(chrposmatrixlist)
    y_g_s <- BMRlist$Y_g_s_all[allg][,1:2, with=F]
    y_g_s[is.na(y_g_s)] <- 0
    mu_g_s <- BMRlist$Mu_g_s_all[allg][,1:2, with=F]
    mu_g_s[is.na(mu_g_s)] <- 0

    glmdtall <- matrixlistToGLM(matrixlisttemp, chrposmatrixlisttemp, BMRlist$BMpars, mu_g_s, y_g_s, fixpars=NULL)
    #glmdtall <- matrixlistToGLM(matrixlist, chrposmatrixlist, BMRlist[[label]]$BMpars, mu_g_s, y_g_s, fixpars=NULL)
    bmrdt[,eval(type):= glmdtall[[1]]$baseline]
    rm(matrixlisttemp,chrposmatrixlisttemp); gc()


  # functional annotation (fanno):data.table, each row has functional annotation for each possible mutation
  fanno <- glmdtall[[1]]

  # row index (ri): chr pos ref alt
  ri <- glmdtall[[2]]


  # mutations (muts): data.table, with columns Chromosome, Position, Ref, Alt, SampleID
  muts0 <- fread(mutf, header = T)
  if (!grepl('chr', muts0$Chromosome[1], fixed = T)) {muts0$Chromosome <- paste0("chr",muts0$Chromosome)}

  # sample annotation (canno):data.table, with columns BMR label, No. syn and phenotype.
  canno0 <- as.data.table(fread(phenof, header = "auto"))
  shared=intersect(muts0$SampleID,canno0$SampleID)
  index1=which(canno0$SampleID %in% shared)
  index2=which(muts0$SampleID %in% shared)
  muts<- muts0[index2,]
  canno = canno0[index1,]

  # column index (ci): sampleID
  ci <- canno[,"SampleID"]
  ci[,"cidx" := 1:dim(canno)[1]]


    BMRlist[["nsyn"]] <- sum(canno$Nsyn)

  # split based on gene
  bmrallg <- split(bmrdt, ri$genename)
  riallg <- split(ri,ri$genename)
  fannoallg <- split(fanno,ri$genename)
#save(fannoallg,file="~/fannoallg.Rd")
#save(riallg,file="~/riallg.Rd")
  # run diffdriver for each gene
  res <- list()
  #for (g in names(bmrallg)) {
    # normalize BMR for each sample
    bmrsc <- log(canno$Nsyn/BMRlist$nsyn)
    # bmrmtx is matrix, rows are positions, columns are for each samples
    #bmrmtx <-sweep(as.matrix(bmrallg[[g]][,canno$BMRlabel,with=F]), 2, bmrsc, "+")
  #  bmr0g=as.matrix(bmrallg[[g]])
  #  bmrg=bmr0g[,rep(1,nrow(canno))]
   # bmrmtx <-sweep(bmrg, 2, bmrsc, "+")
  #}
    ## hotspot
    hotspots=read.table(file = hotf)
    hmm=readRDS(paste0(drivermapsdir, "hmmOGpar_ASHmean.rds"))
for (g in names(bmrallg)) {
    print(paste0("Start to process gene: ", g))
    rig <- riallg[[g]]
    rig$ridx <- 1:dim(rig)[1]
    muti <- na.omit(ci[rig[muts, on = c("chrom"= "Chromosome", "start" = "Position",  "ref" = "Ref",  "alt"= "Alt")], on = "SampleID"])
    mutmtx <- sparseMatrix(i = muti$ridx, j = muti$cidx, dims = c(max(rig$ridx), max(ci$cidx)))
    mutmtx= as.matrix(mutmtx)
    #save(mutmtx,file=paste0("mutmtx_",g,".Rd"))
hotg= na.omit(rig[hotspots,on=c("chrom"="chrom","start"="start")])
    hotmat=rep(0,nrow(rig))
    hotmat[hotg$ridx]=1
    if (sum(mutmtx) ==0) {next}

    # normalize BMR for each sample
    bmr0g=as.matrix(bmrallg[[g]])
    bmrg=as.data.table(bmr0g[,rep(1,nrow(canno))])
    bmrmtx <-as.matrix(sweep(bmrg, 2, bmrsc, "+"))
   if (any(is.na(bmrmtx))) {stop("bmr missing")}
    betaf <- Fpars[[g]][names(Fpars[[g]]) != "beta_f0"]
    betaf0 <- Fpars[[g]]["beta_f0"]
    if (is.null(betaf)){
      betaf <-  Fpars[["TP53"]][names(Fpars[["TP53"]]) != "beta_f0"]
      betaf0 <-  Fpars[["TP53"]]["beta_f0"]
    } # if OG/TSG unknown, use TSG parameters.
    ganno <- fannoallg[[g]]
#save(ganno,file=paste0("fanno_",g,".Rd"))
    fe1 <- as.matrix(ganno[ ,names(betaf), with =F]) %*% betaf + hotmat*hmm[8]+ betaf0
    fe2 <- as.matrix(ganno[ ,names(betaf), with =F]) %*% betaf + betaf0
 	indexmtx=cbind(bmrmtx[,1],ganno[,names(betaf),with=F])
		label=factor(interaction(indexmtx))	
 
fe <- if(g %in% og[,1]){
	fe=fe1
	}else{
	fe=fe2
	}
    resg <- list()
    e=canno[[j]]
    phename=colnames(canno)[j]
    resg[["dd"]] <- ddmodel(mutmtx, e, bmrmtx, fe[,1],label)
    #resg[["dd_nl"]]  <- ddmodel_nl(mutmtx, e, bmrmtx, fe[,1])
    resg[["mlr"]] <- mlr(mutmtx, e)
    resg[["mlr.v2"]] <- mlr.v2(mutmtx, e, canno$Nsyn)
    e_binary=ifelse(e>mean(e),1,0)
    resg[["fisher"]] <- genefisher(mutmtx, e_binary)
    resg[["binom"]] <- genebinom(mutmtx, e_binary)
    resg[["lr"]] <- genelr(mutmtx, e_binary)
    res[[g]] <- resg
    save(mutmtx,canno,bmrmtx, fe, ganno, betaf, betaf0, resg, file=paste0(paste0(outputbase,"_",phename,"_", g, ".Rd")))
    setEPS()
    postscript(file=paste0(outputbase,".",phename,".", g, "mut_status.eps"), width=9, height=4)
    plot_mut(mutmtx, canno,j, bmrmtx, ganno)
    dev.off()
  }

  return(res)
}
